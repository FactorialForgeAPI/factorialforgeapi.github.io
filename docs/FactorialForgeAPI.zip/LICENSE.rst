LICENSE

Copyright (c) 2025 FactForPI Dev by Petrov I.

This library is the result of the author's intellectual work and has been developed without direct borrowing 
of ideas or solutions from existing projects. However, the author does not exclude the possibility of accidental 
coincidence with other developments and respects the rights of other authors, giving them priority.

Permission is granted to freely use, copy, modify, merge, and publish this software, 
as well as to permit the use of this software, provided that the following conditions are met:

1. The above copyright notice and this license must be included in all copies or substantial portions 
   of this software.

2. If you modify this software and distribute it, you must clearly indicate that your version is modified, 
   and provide a description of the changes made. This must be done in an explicit manner so that users 
   can distinguish the original version from the modified one.

This software is provided "as is", without any warranties, express or implied, 
including, but not limited to, warranties of merchantability and fitness for a particular purpose. 
In no event shall the authors or copyright holders be liable for any claims, damages, or other liabilities, 
whether in an action of contract, tort, or otherwise, arising from, out of, or in connection with the use 
of this software.